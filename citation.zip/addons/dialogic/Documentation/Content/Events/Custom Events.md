# Custom events

Since version 1.3, dialogic allows you to easily create your own custom events, without touching it's source code.

You can also easily share your custom event or import one you get from others.

[Learn how to CREATE a custom event](./Custom Events/CreateCustomEvents.md)

[Or how to IMPORT your a custom event](./Custom Events/ImportCustomEvents.md)