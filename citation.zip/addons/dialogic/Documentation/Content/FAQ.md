# FAQ Section

## [How do signals work?](./FAQ/Signals)
## [Portraits not showing in game?](./FAQ/Portraits)
## [Can I use C# with Dialogic?](./FAQ/CSharp)